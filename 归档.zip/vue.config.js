const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true
})
// vue.config.js
module.exports = {
  devServer: {
    proxy: {
      // 当请求路径以 '/api' 开头时，将其代理到目标地址
      '/api': {
        target: 'http://43.134.14.238:3000', // 您的目标 API 地址
        changeOrigin: true, // 改变源，确保请求头中的 Host 字段是目标地址
        pathRewrite: {
          '^/api': '', // 重写路径，将 '/api' 移除
        },
      },
    },
  },
};