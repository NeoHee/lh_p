<template>
  <div id="kline-chart" style="width: 100%; height: 600px;"></div>
  <div class="controls">
    <button @click="changeInterval('1m')" :class="{ active: currentInterval === '1m' }">1 分钟</button>
    <button @click="changeInterval('5m')" :class="{ active: currentInterval === '5m' }">5 分钟</button>
    <button @click="changeInterval('15m')" :class="{ active: currentInterval === '15m' }">15 分钟</button>
    <button @click="toggleMovingAverages">{{ showMovingAverages ? '隐藏均线' : '显示均线' }}</button>
  </div>
  <div v-if="latestTradeInfo" class="trade-info">
    <h3>最新交易信号和 ATR:</h3>
    <p>时间: {{ formatToBeijingTime(latestTradeInfo.close_time, true) }}</p>
    <p>交易方向 (Side):
      <span class="side-highlight" :class="getSideClass(latestTradeInfo.side)">
        {{ formatSideText(latestTradeInfo.side) }}
      </span>
    </p>
    <p>ATR 信息: <span :class="getAtrClass(latestTradeInfo.atr)">{{ latestTradeInfo.atr || '无波动信息' }}</span></p>
    <p>收盘价: {{ latestTradeInfo.close }}</p>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import axios from 'axios';

export default {
  name: 'KlineChart',
  data() {
    return {
      chart: null,
      intervalId: null,
      rawData: {
        '1m': [],
        '5m': [],
        '15m': []
      },
      currentInterval: '1m', // 默认显示 1 分钟数据
      latestTradeInfo: null, // 用于显示最新的 side 和 atr 信息
      showMovingAverages: true, // 控制均线的显示/隐藏
    };
  },
  mounted() {
    this.initChart();
    this.fetchData();
    this.startPolling();
    window.addEventListener('resize', this.resizeChart);
  },
  beforeUnmount() {
    this.stopPolling();
    if (this.chart) {
      this.chart.dispose();
    }
    window.removeEventListener('resize', this.resizeChart);
  },
  methods: {
    initChart() {
      this.chart = echarts.init(document.getElementById('kline-chart'));
      this.renderChart();
    },
    async fetchData() {
      try {
        const response = await axios.get('/api/list');
        this.rawData = response.data;

        if (this.rawData[this.currentInterval] && this.rawData[this.currentInterval].length > 0) {
          this.latestTradeInfo = this.rawData[this.currentInterval][0];
        }

        this.renderChart();
      } catch (error) {
        console.error('获取数据失败:', error);
      }
    },
    startPolling() {
      this.intervalId = setInterval(this.fetchData, 5000);
    },
    stopPolling() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    },
    resizeChart() {
      if (this.chart) {
        this.chart.resize();
      }
    },
    formatData(data) {
      const categoryData = [];
      const values = [];
      const closePrices = [];
      const sideSignals = [];

      const sortedData = [...data].sort((a, b) => new Date(a.close_time) - new Date(b.close_time));

      sortedData.forEach((item) => {
        categoryData.push(this.formatToBeijingTime(item.close_time, true));
        values.push([item.open, item.close, item.low, item.high]);
        closePrices.push(item.close);

        if (item.side) {
          sideSignals.push({
            name: item.side,
            // 使用 formatSideText 来获取简化的显示文本，但保留原始 side 值用于判断颜色和形状
            value: this.formatSideText(item.side), // 这里的 value 会显示在 tooltip 中
            coord: [categoryData.length - 1, item.high > item.low ? item.high : item.low],
            itemStyle: {
              color: this.getSideColor(item.side),
              borderColor: this.getSideColor(item.side),
              borderWidth: 1
            },
            symbol: item.side.includes('buy') ? 'triangle' : (item.side.includes('sell') ? 'diamond' : 'circle'),
            symbolSize: item.side.includes('buy') || item.side.includes('sell') ? 12 : 8,
            symbolOffset: [0, item.side.includes('buy') ? -5 : (item.side.includes('sell') ? 5 : 0)]
          });
        }
      });

      return {
        categoryData,
        values,
        closePrices,
        sideSignals
      };
    },
    // 新增方法：用于统一 side 信号的显示文本
    formatSideText(side) {
      if (!side) return '无信号';
      if (side.includes('buy')) return '买入';
      if (side.includes('sell')) return '卖出';
      return '观望'; // 所有其他情况统一显示为“观望”
    },
    // 获取 side 对应的颜色，用于 markPoint
    getSideColor(side) {
      if (!side) return '#6c757d'; // 灰色
      if (side.includes('buy')) return '#28a745'; // 绿色
      if (side.includes('sell')) return '#dc3545'; // 红色
      return '#6c757d'; // 默认：观望信号也用灰色
    },
    calculateMA(dayCount, data) {
      const result = [];
      for (let i = 0; i < data.length; i++) {
        if (i < dayCount - 1) {
          result.push(null);
          continue;
        }
        let sum = 0;
        for (let j = 0; j < dayCount; j++) {
          sum += data[i - j][1];
        }
        result.push(parseFloat((sum / dayCount).toFixed(2)));
      }
      return result;
    },
    formatToBeijingTime(isoString, addExtra8Hours = false) {
        let date = new Date(isoString);
        if (addExtra8Hours) {
            const utcMillis = date.getTime();
            const extra8HoursMillis = 8 * 60 * 60 * 1000;
            date = new Date(utcMillis + extra8HoursMillis);
        }
        return date.toLocaleString('zh-CN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false,
            timeZone: 'Asia/Shanghai'
        }).replace(/\//g, '-');
    },
    toggleMovingAverages() {
      this.showMovingAverages = !this.showMovingAverages;
      this.renderChart();
    },
    changeInterval(interval) {
      if (['1m', '5m', '15m'].includes(interval)) {
        this.currentInterval = interval;
        this.renderChart();
        if (this.rawData[this.currentInterval] && this.rawData[this.currentInterval].length > 0) {
          this.latestTradeInfo = this.rawData[this.currentInterval][0];
        } else {
          this.latestTradeInfo = null;
        }
      } else {
        console.warn('无效的时间间隔:', interval);
      }
    },
    getSideClass(side) {
      if (!side) return '';
      if (side.includes('buy')) return 'side-buy';
      if (side.includes('sell')) return 'side-sell';
      return 'side-neutral'; // 观望的样式
    },
    getAtrClass(atr) {
      if (!atr) return '';
      if (atr.includes('爆发')) return 'atr-high-volatility';
      return '';
    },
    renderChart() {
      if (!this.chart || !this.rawData[this.currentInterval] || this.rawData[this.currentInterval].length === 0) {
        return;
      }

      const { categoryData, values, closePrices, sideSignals } = this.formatData(this.rawData[this.currentInterval]);

      const series = [
        {
          name: 'Candlestick',
          type: 'candlestick',
          data: values,
          itemStyle: {
            color: '#ef232a',
            color0: '#14b14f',
            borderColor: '#ef232a',
            borderColor0: '#14b14f',
            barWidth: '60%',
          },
          emphasis: {
            itemStyle: {
              borderColor: 'auto',
              borderWidth: 1
            }
          },
          markLine: {
            silent: true,
            data: [
              {
                name: '最高价',
                type: 'max',
                valueDim: 'highest',
                lineStyle: {
                  color: '#FF4500',
                  type: 'solid',
                  width: 2
                },
                label: {
                  show: true,
                  position: 'insideStartTop',
                  formatter: 'H: {c}',
                  color: '#FF4500',
                  fontSize: 12,
                  distance: 10,
                  overflow: 'breakAll',
                  lineHeight: 14
                }
              },
              {
                name: '最低价',
                type: 'min',
                valueDim: 'lowest',
                lineStyle: {
                  color: '#008000',
                  type: 'solid',
                  width: 2
                },
                label: {
                  show: true,
                  position: 'insideStartBottom',
                  formatter: 'L: {c}',
                  color: '#008000',
                  fontSize: 12,
                  distance: 10,
                  overflow: 'breakAll',
                  lineHeight: 14
                }
              }
            ],
            label: {
              show: false
            }
          },
          markPoint: {
            data: sideSignals,
            symbolSize: 12,
            tooltip: {
                formatter: function (param) {
                    // param.value 现在直接是 '买入', '卖出', '观望'
                    if (param.seriesType === 'candlestick' && param.componentType === 'markPoint') {
                        return '信号: ' + param.value + '<br/>时间: ' + param.name;
                    }
                    return null;
                }
            }
          }
        },
        {
          name: '收盘价连线',
          type: 'line',
          data: closePrices,
          smooth: true,
          lineStyle: {
            opacity: 0.8,
            width: 2,
            color: '#9400D3'
          },
          showSymbol: false,
          legendHoverLink: false
        }
      ];

      if (this.showMovingAverages) {
        const ma5 = this.calculateMA(5, values);
        const ma10 = this.calculateMA(10, values);
        const ma20 = this.calculateMA(20, values);

        series.push({
          name: 'MA5',
          type: 'line',
          data: ma5,
          smooth: true,
          lineStyle: {
            opacity: 1,
            width: 2,
            color: '#FF00FF'
          },
          showSymbol: false
        });
        series.push({
          name: 'MA10',
          type: 'line',
          data: ma10,
          smooth: true,
          lineStyle: {
            opacity: 1,
            width: 2,
            color: '#00FFFF'
          },
          showSymbol: false
        });
        series.push({
          name: 'MA20',
          type: 'line',
          data: ma20,
          smooth: true,
          lineStyle: {
            opacity: 1,
            width: 2,
            color: '#DAA520'
          },
          showSymbol: false
        });
      }

      const option = {
        title: {
          text: `K 线图 (${this.currentInterval} 数据)`,
          left: 'center',
          textStyle: {
            color: '#333'
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            label: {
              backgroundColor: '#6a7985'
            }
          },
          formatter: (params) => {
            let res = '';
            if (params && params.length > 0 && params[0].name) {
                res = `时间: ${params[0].name}<br/>`;
            }

            params.forEach(function (item) {
              if (item.seriesName === 'Candlestick') {
                const open = item.value[0];
                const close = item.value[1];
                const low = item.value[2];
                const high = item.value[3];
                const color = open <= close ? '#ef232a' : '#14b14f';
                res += `<span style="display:inline-block;margin-right:4px;border-radius:10px;width:10px;height:10px;background-color:${color};"></span>`;
                res += `开盘: ${open}<br/>`;
                res += `收盘: ${close}<br/>`;
                res += `最低: ${low}<br/>`;
                res += `最高: ${high}<br/>`;
              } else if (item.value !== null) {
                res += `<span style="display:inline-block;margin-right:4px;border-radius:10px;width:10px;height:10px;background-color:${item.color};"></span>`;
                res += `${item.seriesName}: ${item.value}<br/>`;
              }
            });
            const markPointParam = params.find(p => p.componentType === 'markPoint' && p.seriesType === 'candlestick');
            if (markPointParam && markPointParam.value) {
                res += `<br/><strong>信号: ${markPointParam.value}</strong>`;
            }

            return res;
          }
        },
        legend: {
          data: ['Candlestick', '收盘价连线'].concat(this.showMovingAverages ? ['MA5', 'MA10', 'MA20'] : []),
          top: 30,
          left: 'center',
          textStyle: {
            color: '#333'
          }
        },
        grid: {
          left: '8%',
          right: '8%',
          bottom: '15%',
          top: '15%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: categoryData,
          scale: true,
          boundaryGap: true,
          axisLine: { onZero: false, lineStyle: { color: '#ccc' } },
          splitLine: { show: false },
          axisLabel: {
            color: '#333',
            formatter: function (value) {
                const parts = value.split(' ');
                if (parts.length > 1) {
                  return `${parts[0].substring(5)}\n${parts[1].substring(0,5)}`;
                }
                return value.substring(5, 16);
            }
          },
          axisTick: {
            alignWithLabel: true
          }
        },
        yAxis: {
          scale: true,
          axisLine: { lineStyle: { color: '#ccc' } },
          splitLine: {
            show: true,
            lineStyle: {
              color: '#eee',
              type: 'dashed'
            }
          },
          axisLabel: {
            color: '#333'
          }
        },
        dataZoom: [
          {
            type: 'inside',
            xAxisIndex: [0, 1],
            startValue: Math.max(0, categoryData.length - 60),
            endValue: categoryData.length - 1
          },
          {
            show: true,
            type: 'slider',
            xAxisIndex: [0, 1],
            top: '90%',
            height: 20,
            handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4-9,0.3-9.1,0.6-9.1,0.6c0-0.1,0-0.2,0-0.3c0.1-0.2,0.1-0.4,0.2-0.5h9.2c0.2,0,0.4,0,0.5,0.1v-1.2C10.7,11.9,10.7,11.9,10.7,11.9z',
            handleSize: '100%',
            handleStyle: {
              color: '#fff',
              shadowBlur: 3,
              shadowColor: 'rgba(0, 0, 0, 0.6)',
              shadowOffsetX: 2,
              shadowOffsetY: 2
            },
            textStyle: {
              color: '#333'
            }
          }
        ],
        series: series
      };

      this.chart.setOption(option);
    },
  }
};
</script>

<style scoped>
#kline-chart {
  margin: 20px auto;
  border: 1px solid #ddd;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.controls {
  text-align: center;
  margin-bottom: 20px;
}

.controls button {
  padding: 8px 15px;
  margin: 0 5px;
  border: 1px solid #007bff;
  border-radius: 4px;
  background-color: #fff;
  color: #007bff;
  cursor: pointer;
  transition: background-color 0.3s, color 0.3s;
}

.controls button:hover {
  background-color: #e2f0ff;
}

.controls button.active {
  background-color: #007bff;
  color: #fff;
}

.trade-info {
  margin-top: 30px;
  padding: 15px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background-color: #f9f9f9;
  text-align: left;
  max-width: 600px;
  margin: 30px auto;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
}

.trade-info h3 {
  color: #333;
  margin-top: 0;
  border-bottom: 1px solid #eee;
  padding-bottom: 10px;
  margin-bottom: 15px;
}

.trade-info p {
  margin: 8px 0;
  color: #555;
  line-height: 1.5;
}

/* ATR 信号样式 */
.atr-high-volatility {
  color: #ffc107;
  font-weight: bold;
  text-decoration: underline;
}

/* 着重强调 side 信号 */
.side-highlight {
  font-size: 1.1em;
  font-weight: bold;
  padding: 3px 8px;
  border-radius: 4px;
  display: inline-block;
  margin-left: 5px;
  text-transform: uppercase; /* 仍然保持大写，如果不需要可以移除 */
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

/* Side 信号样式 */
.side-buy {
  color: #fff;
  background-color: #28a745; /* 绿色背景 */
}

.side-sell {
  color: #fff;
  background-color: #dc3545; /* 红色背景 */
}

.side-neutral {
  color: #555;
  background-color: #f0f0f0; /* 浅灰色背景 */
}
</style>