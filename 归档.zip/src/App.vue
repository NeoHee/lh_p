<template>
  <div id="app">
    <h1>Real-time K-Line Chart</h1>
    <button @click="changeChartInterval('1m')">1 Minute</button>
    <button @click="changeChartInterval('5m')">5 Minutes</button>
    <button @click="changeChartInterval('15m')">15 Minutes</button>
    <KlineChart ref="klineChartRef" />
  </div>
</template>

<script>
import KlineChart from './components/KlineChart.vue';

export default {
  name: 'App',
  components: {
    KlineChart
  },
  methods: {
    changeChartInterval(interval) {
      // Call the method in the child component to change the interval
      if (this.$refs.klineChartRef) {
        this.$refs.klineChartRef.changeInterval(interval);
      }
    }
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

button {
  margin: 10px;
  padding: 8px 15px;
  cursor: pointer;
}
</style>